
// Função para carregar os dados e exibir na tabela    OK
async function carregarDadosConsulta() {
  try {
    const resposta = await fetch('http://localhost:8080/CRUD/Convidados');
    const dados = await resposta.json();

    // console.log(dados);

    const tabelaCorpoConsulta = document.getElementById('tabelaCorpoConsulta');
    tabelaCorpoConsulta.innerHTML = '';

    dados.forEach((convidado) => {
      const linha = document.createElement('tr');
      linha.innerHTML = `
        <td>${convidado.idpessoa}</td>
        <td>${convidado.nome}</td>
        <td>${convidado.evento}</td>
        <td>${convidado.email}</td>
        <td>${convidado.telefone}</td>
        <td>${convidado.confirmacao}</td>
      `;
      tabelaCorpoConsulta.appendChild(linha);
    });

  } catch (erro) {
    console.error('Erro ao carregar dados:', erro);
  }
}

// Função para inserir um novo convidado    OK
async function inserirDado() {
//   const formularioInserir = document.getElementById('formularioInserir');
//   const formData = new FormData(formularioInserir);

//     console.log(formData);
const data = {
    nome: document.getElementById("nomeInserir").value,
    evento: document.getElementById("eventoInserir").value,
    email: document.getElementById("emailInserir").value,
    telefone: document.getElementById("telefoneInserir").value,
    confirmacao: document.getElementById("Confirmacao").value
};

var url = "http://localhost:8080/CRUD/Convidados";
  try {
    const resposta = await fetch(url, {
      method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Access-Control-Allow-Methods': '*'
    //   },
      body: JSON.stringify(data)
    });

    const novoDado = await resposta.json();
    console.log('Novo dado inserido:', novoDado);

    // Reinicia o formulário
    formularioInserir.reset();

    // Recarrega os dados após a inserção
    carregarDadosConsulta();

  } catch (erro) {
    console.error('Erro ao inserir dado:', erro);
  }
}

// Função para alterar um convidado    OK
async function alterarDado() {
    const data = {
        idpessoa: document.getElementById("idAlterar").value,
        nome: document.getElementById("nomeAlterar").value,
        evento: document.getElementById("eventoAlterar").value,
        email: document.getElementById("emailAlterar").value,
        telefone: document.getElementById("telefoneAlterar").value,
        confirmacao: document.getElementById("Confirmacao").value
    };

  var url = `http://localhost:8080/CRUD/Convidados`;

  try {
    const resposta = await fetch(url, {
      method: 'PUT',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
      body: JSON.stringify(data)
    });

    const dadoAlterado = await resposta.json();
    console.log('Dado alterado:', dadoAlterado);

    // Reinicia o formulário
    formularioAlterar.reset();

    // Atualiza a página de consulta após a alteração
    carregarDadosConsulta();
    window.location.reload();

  } catch (erro) {
    console.error('Erro ao alterar dado:', erro);
  }
}

// Função para excluir um convidado
async function excluirDado() {
//   const formularioExcluir = document.getElementById('formularioExcluir');
//   const formData = new FormData(formularioExcluir);
var idExcluir = document.getElementById("idExcluir").value;

// console.log(idExcluir);

var url = `http://localhost:8080/CRUD/Convidados/${idExcluir}`;

// console.log(url);
  try {
    const resposta = await fetch(url, {
      method: 'DELETE'
    //   headers: {
    //     'Content-Type': 'application/json',
    //   }
    //   body: JSON.stringify(Object.fromEntries(formData)),
    });

    const dadoExcluido = await resposta.json();
    console.log('Dado excluído:', dadoExcluido);

    // Reinicia o formulário
    formularioExcluir.reset();

    // Atualiza a página de consulta após a exclusão
    // carregarDadosConsulta();

  } catch (erro) {
    console.error('Erro ao excluir dado:', erro);
  }
}

// Função para carregar os dados ao carregar a página
// window.onload = carregarDadosConsulta;
